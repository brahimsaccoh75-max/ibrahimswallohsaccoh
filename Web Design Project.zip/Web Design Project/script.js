// Wait for the DOM to fully load
document.addEventListener('DOMContentLoaded', () => {

    // --- 1. Highlights Carousel Functionality ---
    const carouselCards = document.getElementById('carouselCards');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');

    if (carouselCards && prevBtn && nextBtn) {
        // How much to scroll each click (card width + gap)
        const scrollAmount = 270; 

        nextBtn.addEventListener('click', () => {
            carouselCards.scrollBy({
                left: scrollAmount,
                behavior: 'smooth'
            });
        });

        prevBtn.addEventListener('click', () => {
            carouselCards.scrollBy({
                left: -scrollAmount,
                behavior: 'smooth'
            });
        });
    }

    // --- 2. "Join Now" Button Alert ---
    const joinBtn = document.getElementById('joinBtn');
    if (joinBtn) {
        joinBtn.addEventListener('click', () => {
            alert("Thank you for your interest! The SLFA registration portal for the 2026 season will open soon.");
        });
    }

    // --- 3. Watch Kickoff Interaction ---
    const ctaBtn = document.querySelector('.cta-btn');
    const video = document.querySelector('video');
    
    if (ctaBtn && video) {
        ctaBtn.addEventListener('click', () => {
            video.scrollIntoView({ behavior: 'smooth' });
            video.play();
        });
    }

    // --- 4. Simple Scroll-to-Top Footer Logic ---
    const copyright = document.querySelector('.copyright');
    if (copyright) {
        copyright.style.cursor = 'pointer';
        copyright.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
});